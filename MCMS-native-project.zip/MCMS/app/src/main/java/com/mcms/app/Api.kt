package com.mcms.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Native client for the PHP JSON API (index.php). Keeps the session cookie across launches. */
object Api {
    const val BASE = "https://mcmodshared.page.gd/"
    const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val jar = LinkedHashMap<String, String>()
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("mcms", Context.MODE_PRIVATE)
        prefs.getString("cookies", "")!!.split(";").forEach {
            val i = it.indexOf('='); if (i > 0) jar[it.substring(0, i).trim()] = it.substring(i + 1).trim()
        }
    }
    fun cookieHeader() = jar.entries.joinToString("; ") { "${it.key}=${it.value}" }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun get(action: String, extra: String = ""): JSONObject = call("?action=$action$extra", null)
    suspend fun post(action: String, vararg p: Pair<String, String>): JSONObject =
        call("?action=$action", p.joinToString("&") { enc(it.first) + "=" + enc(it.second) })

    private suspend fun call(path: String, body: String?): JSONObject = withContext(Dispatchers.IO) {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.setRequestProperty("User-Agent", UA); c.setRequestProperty("Accept", "application/json, text/plain, */*"); c.setRequestProperty("Accept-Language", "id,en;q=0.8")
            if (jar.isNotEmpty()) c.setRequestProperty("Cookie", cookieHeader())
            if (body != null) {
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            c.headerFields["Set-Cookie"]?.forEach {
                val kv = it.substringBefore(';'); val i = kv.indexOf('=')
                if (i > 0) jar[kv.substring(0, i).trim()] = kv.substring(i + 1).trim()
            }
            prefs.edit().putString("cookies", jar.entries.joinToString(";") { "${it.key}=${it.value}" }).apply()
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
            val j = try { JSONObject(text) } catch (e: Exception) { throw Exception("HTTP $code: " + text.replace(Regex("\\s+"), " ").take(160)) }
            if (!j.optBoolean("ok", true) && j.has("error")) throw Exception(j.optString("error"))
            j
        } finally { c.disconnect() }
    }
}
