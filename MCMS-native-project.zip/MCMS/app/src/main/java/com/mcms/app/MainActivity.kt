package com.mcms.app

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val INK = 0xFF2A2230.toInt(); private val PAPER = 0xFFEAD9B6.toInt(); private val CARD = 0xFFFFFAF0.toInt()
    private val GREEN = 0xFF7CCF5A.toInt(); private val SUN = 0xFFFFD23F.toInt(); private val SKY = 0xFF8FD3FF.toInt()
    private val PINK = 0xFFFF93B5.toInt(); private val MUTED = 0xFF6B5F73.toInt()
    private lateinit var root: FrameLayout
    private val screens = ArrayList<View>()
    private var user: JSONObject? = null
    private var homeLoad: (() -> Unit)? = null

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun tr(id: String, en: String) = if (Locale.getDefault().language in listOf("in", "id")) id else en
    private fun JSONObject.s(k: String) = if (isNull(k)) "" else optString(k)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun box(fill: Int, r: Int = 14, stroke: Int = 3) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); setStroke(dp(stroke), INK)
    }
    private fun tv(text: String, size: Float = 16f, bold: Boolean = false, color: Int = INK) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun btn(text: String, fill: Int = GREEN, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(INK); typeface = Typeface.DEFAULT_BOLD
        background = box(fill, 12); stateListAnimator = null; minHeight = 0; minimumHeight = 0
        setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() }
    }
    private fun field(hint: String, pw: Boolean = false) = EditText(this).apply {
        this.hint = hint; background = box(Color.WHITE, 12); setTextColor(INK); setHintTextColor(0xFF8B8093.toInt())
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else isSingleLine = true
    }
    private fun LinearLayout.add(v: View, top: Int = 8, w: Int = MATCH_PARENT) =
        addView(v, LinearLayout.LayoutParams(w, WRAP_CONTENT).apply { topMargin = dp(top) })
    private fun vcol(pad: Int = 12) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)) }
    private fun catName(c: String) = when (c) { "texture" -> "Texture Pack"; "skin" -> "Skin Pack"; else -> "Addon" }
    private fun fmtDate(t: Long) = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(t * 1000))
    private fun fmtSize(n: Long) = if (n < 1048576) "%.1f KB".format(n / 1024.0) else "%.1f MB".format(n / 1048576.0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Api.init(this)
        window.statusBarColor = PAPER; window.navigationBarColor = PAPER
        WindowInsetsControllerCompat(window, window.decorView).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
        root = FrameLayout(this).apply { setBackgroundColor(PAPER) }
        setContentView(root)
        push(home())
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (screens.size > 1) pop() else finish() }
        })
        if (Build.VERSION.SDK_INT <= 28) requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        lifecycleScope.launch { refreshUser(); homeLoad?.invoke() }
    }

    private suspend fun refreshUser() {
        user = try { val d = Api.get("me"); if (d.optBoolean("logged")) d.getJSONObject("user") else null } catch (e: Exception) { null }
    }
    private fun push(v: View) { root.removeAllViews(); root.addView(v, MATCH_PARENT, MATCH_PARENT); screens.add(v) }
    private fun pop() { screens.removeAt(screens.size - 1); root.removeAllViews(); root.addView(screens.last(), MATCH_PARENT, MATCH_PARENT) }

    // ---------------- Home ----------------
    private class Card(val v: LinearLayout, val img: ImageView, val cat: TextView, val title: TextView, val desc: TextView, val meta: TextView) : RecyclerView.ViewHolder(v)

    private fun home(): View {
        var cat = ""
        val items = ArrayList<JSONObject>()
        val col = vcol()
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tv("MC MOD SHARE", 20f, true).apply { background = box(SUN, 10, 2); setPadding(dp(12), dp(4), dp(12), dp(4)) })
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(btn("👤", SKY) { account() }, LinearLayout.LayoutParams(dp(56), dp(44)))
        col.addView(bar)
        val search = field(tr("Cari file, user, judul...", "Search files, users, titles...")).apply { imeOptions = EditorInfo.IME_ACTION_SEARCH }
        col.add(search, 10)
        val cats = listOf("" to tr("Semua", "All"), "addon" to "Addon", "texture" to "Texture", "skin" to "Skin")
        val chips = ArrayList<Button>(); val row = LinearLayout(this)
        fun paint() = chips.forEachIndexed { i, b -> b.background = box(if (cats[i].first == cat) GREEN else Color.WHITE, 12) }
        cats.forEach { (k, n) ->
            val b = btn(n, Color.WHITE) { cat = k; paint(); homeLoad?.invoke() }; chips.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(6) })
        }
        paint(); col.add(row, 8)
        val empty = tv(tr("Belum ada file.", "No files yet."), 18f, color = MUTED).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        col.add(empty, 16)
        val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = items.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val v = vcol().apply { background = box(CARD); layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(12) } }
                val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xFFF1E7CF.toInt()) }
                v.addView(img, LinearLayout.LayoutParams(MATCH_PARENT, dp(190)))
                val c = tv("", 13f, true).apply { background = box(SKY, 20, 2); setPadding(dp(10), dp(1), dp(10), dp(1)) }
                v.add(c, 8, WRAP_CONTENT)
                val ti = tv("", 20f, true); v.add(ti, 4)
                val de = tv("", 15f).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END }; v.add(de, 4)
                val me = tv("", 13f, color = MUTED); v.add(me, 4)
                return Card(v, img, c, ti, de, me)
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                h as Card; val f = items[i]
                h.title.text = f.s("title"); h.cat.text = catName(f.s("category")); h.desc.text = f.s("description")
                h.desc.visibility = if (f.s("description").isEmpty()) View.GONE else View.VISIBLE
                h.meta.text = "@${f.s("username")} · ${f.optInt("downloads")} ${tr("unduhan", "downloads")} · ${fmtSize(f.optLong("size"))}"
                val ids = f.s("cover_ids")
                val url = if (ids.isNotEmpty()) Api.BASE + "?action=cover_img&cid=" + ids.split(",")[0]
                else if (f.s("cover_name").isNotEmpty()) Api.BASE + "?action=cover&id=" + f.optInt("id") else null
                if (url != null) { h.img.visibility = View.VISIBLE; h.img.load(url) } else h.img.visibility = View.GONE
                h.v.setOnClickListener { push(detail(f.optInt("id"))) }
            }
        }
        val rv = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@MainActivity); this.adapter = adapter; clipToPadding = false; setPadding(0, dp(8), 0, dp(16)) }
        col.addView(rv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        homeLoad = {
            lifecycleScope.launch {
                try {
                    val d = Api.get("list", "&q=" + enc(search.text.toString().trim()) + "&category=" + cat)
                    items.clear(); val a = d.getJSONArray("files")
                    for (i in 0 until a.length()) items.add(a.getJSONObject(i))
                    adapter.notifyDataSetChanged(); empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                } catch (e: Exception) { toast(e.message ?: "Error") }
            }
        }
        search.setOnEditorActionListener { _, _, _ -> homeLoad?.invoke(); true }
        return col
    }

    private fun account() {
        val u = user
        if (u == null) { push(auth()); return }
        AlertDialog.Builder(this).setTitle("@" + u.s("username")).setMessage(u.s("display_name"))
            .setPositiveButton(tr("Keluar", "Log out")) { _, _ -> lifecycleScope.launch { try { Api.post("logout") } catch (e: Exception) { }; user = null; toast(tr("Sudah keluar", "Logged out")) } }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    // ---------------- Detail ----------------
    private fun detail(id: Int): View {
        val scroll = ScrollView(this); val col = vcol(14); scroll.addView(col)
        col.addView(btn("←  " + tr("Kembali", "Back"), Color.WHITE) { pop() }, LinearLayout.LayoutParams(WRAP_CONTENT, dp(44)))
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; col.add(body, 10)
        fun render() { lifecycleScope.launch { try { build(body, Api.get("detail", "&id=$id")) { render() } } catch (e: Exception) { toast(e.message ?: "Error") } } }
        render(); return scroll
    }

    private fun build(body: LinearLayout, d: JSONObject, reload: () -> Unit) {
        body.removeAllViews()
        val f = d.getJSONObject("file"); val id = f.optInt("id")
        val cv = d.optJSONArray("covers"); val urls = (0 until (cv?.length() ?: 0)).map { Api.BASE + cv!!.getString(it) }
        if (urls.isNotEmpty()) {
            val frame = FrameLayout(this).apply { background = box(0xFFF1E7CF.toInt()) }
            val vp = ViewPager2(this)
            vp.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                override fun getItemCount() = urls.size
                override fun onCreateViewHolder(p: ViewGroup, t: Int) = object : RecyclerView.ViewHolder(ImageView(this@MainActivity).apply {
                    layoutParams = ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT); scaleType = ImageView.ScaleType.FIT_CENTER }) {}
                override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) { (h.itemView as ImageView).load(urls[i]) }
            }
            frame.addView(vp, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            if (urls.size > 1) {
                val cnt = tv("1/${urls.size}", 13f, true).apply { background = box(CARD, 20, 2); setPadding(dp(10), dp(1), dp(10), dp(1)) }
                frame.addView(cnt, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.END or Gravity.TOP).apply { setMargins(0, dp(8), dp(8), 0) })
                vp.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() { override fun onPageSelected(p: Int) { cnt.text = "${p + 1}/${urls.size}" } })
            }
            body.addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, dp(230)))
        }
        body.add(tv(catName(f.s("category")), 13f, true).apply { background = box(SKY, 20, 2); setPadding(dp(10), dp(1), dp(10), dp(1)) }, 10, WRAP_CONTENT)
        body.add(tv(f.s("title"), 24f, true), 6)
        body.add(tv("${f.s("original_name")} · ${fmtSize(f.optLong("size"))}\n${tr("Oleh", "By")} @${f.s("username")} · ${fmtDate(f.optLong("created_at"))} · ${f.optInt("downloads")} ${tr("unduhan", "downloads")}", 14f, color = MUTED), 4)
        val desc = vcol().apply { background = box(SUN) }
        desc.addView(tv(tr("Tentang mod ini", "About this mod"), 17f, true))
        desc.add(tv(f.s("description").ifEmpty { tr("Pembuat belum menambahkan deskripsi.", "The creator has not added a description.") }, 16f), 6)
        body.add(desc, 12)
        val src = f.s("source_url")
        body.add(if (src.isNotEmpty()) btn(tr("BUKA LINK", "OPEN LINK")) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(src))) }
        else btn(tr("UNDUH FILE", "DOWNLOAD FILE")) { download(id, f.s("original_name")) }, 12)
        // rating
        val r = d.getJSONObject("rating"); val avg = r.optDouble("avg", 0.0)
        val rb = vcol().apply { background = box(Color.WHITE) }
        rb.addView(tv("Rating", 17f, true))
        val stars = LinearLayout(this)
        for (n in 1..5) stars.addView(tv("★", 34f, color = if (n <= Math.round(avg)) SUN else 0xFFD9CDB9.toInt()).apply {
            setOnClickListener { rate(id, n, reload) } }, LinearLayout.LayoutParams(dp(40), WRAP_CONTENT))
        rb.add(stars, 4); rb.add(tv("%.1f/5 · %d rating".format(avg, r.optInt("count")), 14f, color = MUTED), 2)
        body.add(rb, 12)
        // comments
        val cb = vcol().apply { background = box(Color.WHITE) }
        val cs = d.getJSONArray("comments")
        cb.addView(tv(tr("Komentar", "Comments") + " (${cs.length()})", 17f, true))
        if (cs.length() == 0) cb.add(tv(tr("Belum ada komentar.", "No comments yet."), 15f, color = MUTED), 8)
        for (i in 0 until cs.length()) {
            val c = cs.getJSONObject(i); val reply = c.optInt("parent_id") != 0
            val item = vcol(0).apply { if (reply) setPadding(dp(18), 0, 0, 0) }
            item.addView(tv("${c.s("display_name").ifEmpty { c.s("username") }}  @${c.s("username")} · ${fmtDate(c.optLong("created_at"))}", 13f, true))
            item.add(tv(c.s("body"), 16f), 2); cb.add(item, 10)
        }
        if (user != null) {
            val input = field(tr("Tulis komentar…", "Write a comment…"))
            cb.add(input, 12)
            cb.add(btn(tr("Kirim", "Send")) {
                val t = input.text.toString().trim(); if (t.isEmpty()) return@btn
                lifecycleScope.launch { try { Api.post("comment", "file_id" to "$id", "body" to t); reload() } catch (e: Exception) { toast(e.message ?: "Error") } }
            }, 8)
        } else cb.add(btn(tr("Login untuk komentar & rating", "Log in to comment & rate"), SKY) { push(auth()) }, 12)
        body.add(cb, 12)
    }

    private fun rate(id: Int, n: Int, reload: () -> Unit) {
        if (user == null) { push(auth()); return }
        lifecycleScope.launch { try { Api.post("rate", "file_id" to "$id", "rating" to "$n"); reload() } catch (e: Exception) { toast(e.message ?: "Error") } }
    }

    private fun download(id: Int, name: String) {
        if (user == null) { toast(tr("Login dulu untuk mengunduh", "Log in to download")); push(auth()); return }
        try {
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { "file_$id" }
            val req = DownloadManager.Request(Uri.parse(Api.BASE + "?action=download&id=$id")).setTitle(safe)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .addRequestHeader("Cookie", Api.cookieHeader()).addRequestHeader("User-Agent", Api.UA)
            val pub = Build.VERSION.SDK_INT > 28 || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            if (pub) req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safe)
            else req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, safe)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast(tr("Mengunduh: ", "Downloading: ") + safe)
        } catch (e: Exception) { toast(e.message ?: "Error") }
    }

    // ---------------- Auth ----------------
    private fun auth(): View {
        var login = true
        val col = vcol(16)
        col.addView(btn("←  " + tr("Kembali", "Back"), Color.WHITE) { pop() }, LinearLayout.LayoutParams(WRAP_CONTENT, dp(44)))
        col.add(tv("MC MOD SHARE", 26f, true), 16)
        val u = field("Username").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS }
        val p = field("Password", true); val status = tv("", 15f, color = 0xFFD6254A.toInt())
        val submit = btn("") {}
        val tabs = LinearLayout(this); val bl = btn(tr("Masuk", "Login")) {}; val br = btn(tr("Daftar", "Register"), Color.WHITE) {}
        fun paint() { bl.background = box(if (login) GREEN else Color.WHITE, 12); br.background = box(if (login) Color.WHITE else GREEN, 12)
            submit.text = if (login) tr("MASUK", "LOGIN") else tr("BUAT AKUN", "CREATE ACCOUNT") }
        bl.setOnClickListener { login = true; paint() }; br.setOnClickListener { login = false; paint() }
        tabs.addView(bl, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) }); tabs.addView(br, LinearLayout.LayoutParams(0, dp(44), 1f))
        col.add(tabs, 12); col.add(u, 12); col.add(p, 8); col.add(submit, 12); col.add(status, 8)
        submit.setOnClickListener {
            lifecycleScope.launch {
                try {
                    Api.post(if (login) "login" else "register", "username" to u.text.toString().trim(), "password" to p.text.toString())
                    refreshUser(); toast(tr("Berhasil ✓", "Success ✓")); pop(); homeLoad?.invoke()
                } catch (e: Exception) { status.text = e.message ?: "Error" }
            }
        }
        paint(); return col
    }
}
