# MCMS (MC MOD SHARE) – Native Android (Kotlin, tanpa WebView)
Memakai API JSON dari index.php di https://mcmodshared.page.gd. minSdk 21, tanpa library native (32-bit & 64-bit).
Fitur: daftar + cari + kategori, detail dengan cover geser (ViewPager2), deskripsi, rating, komentar, login/daftar, unduh.
Build: Android Studio (Build ▸ Build APK) atau GitHub ▸ Actions ▸ "Build MCMS APK".
Belum ada: layar unggah file & edit profil (masih lewat website).
